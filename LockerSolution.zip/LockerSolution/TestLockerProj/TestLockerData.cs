﻿using System;
using LockerBank;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestLockerProj
{
    [TestClass]
    public class TestLockerData
    {
        private LockerData _lockerData = new LockerData();

        [TestMethod]
        public void TestMethod()
        {
            _lockerData.AddLocationInfo("SYD", "LB1", 40);
            _lockerData.AddLocationInfo("MEL", "LB1", 20);
            _lockerData.AddLocationInfo("SYD", "LB2", 30);
            _lockerData.AddLocationInfo("SYD", "LB3", 70);
            _lockerData.MultiDict.TryGetValue("SYD", "LB1", out int actual);
            Assert.AreEqual(actual,40);
        }

        [TestMethod]
        public void InvalidTestMethod()
        {
            _lockerData.AddLocationInfo("SYD", "LB1", 40);
            _lockerData.AddLocationInfo("MEL", "LB1", 20);
            _lockerData.AddLocationInfo("SYD", "LB2", 30);
            _lockerData.AddLocationInfo("SYD", "LB3", 70);
            _lockerData.MultiDict.TryGetValue("SYD", "LB1", out int actual);
            Assert.AreNotEqual(actual, 20);
        }
    }
}
