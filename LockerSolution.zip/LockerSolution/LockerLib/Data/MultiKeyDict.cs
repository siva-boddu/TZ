﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace LockerBank
{
    /// <summary>
    /// Custom Dictionary Class
    /// </summary>	
    /// <typeparam name="K">Primary Key Type</typeparam>
    /// <typeparam name="L">Sub Key Type</typeparam>
    /// <typeparam name="V">Value Type</typeparam>
    public class MultiKeyDict<K, L, V>
    {
        public bool TryGetValue(K primaryKey, L subKey, out V val)
        {
            try
            {
                var tuple = Tuple.Create(primaryKey, subKey);
                return TupleDictionary.TryGetValue(tuple, out val);
            }
            finally
            {
            }
        }

        public void Remove(K primaryKey, L subKey)
        {
            try
            {
                var tuple = Tuple.Create(primaryKey, subKey);
                if (TupleDictionary.ContainsKey(tuple))
                {
                    TupleDictionary.Remove(tuple);
                }
            }
            finally
            {
            }
        }

        public void Add(K primaryKey, L subKey, V val)
        {
            var keyMapping = Tuple.Create(primaryKey, subKey);
            try
            {
                if (!TupleDictionary.ContainsKey(keyMapping))
                    TupleDictionary.Add(keyMapping, val);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Clear()
        {
            try
            {
                TupleDictionary.Clear();

            }
            finally
            {

            }
        }

        public int Count
        {
            get
            {
                try
                {
                    return TupleDictionary.Count;
                }
                finally
                {
                }
            }
        }

        internal Dictionary<Tuple<K, L>, V> TupleDictionary { get; set; } = new Dictionary<Tuple<K, L>, V>();

        public Dictionary<Tuple<K, L>, V>.Enumerator GetEnumerator()
        {
            try
            {
                return TupleDictionary.GetEnumerator();
            }
            finally
            {
            }
        }
    }
}
