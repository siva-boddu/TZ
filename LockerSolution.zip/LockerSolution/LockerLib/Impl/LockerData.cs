﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LockerBank
{
    public class LockerData : ILockerManager
    {
        public MultiKeyDict<string, string, int> MultiDict = new MultiKeyDict<string, string, int>();

        public List<string> LockerBank { get; set; } = null;

        public List<string> LockerLocation { get; set; } = null;

        public LockerData()
        {
            LockerLocation = new List<string>();
            LockerBank = new List<string>();
        }

        public void LoadLockerLocationData()
        {
            LockerLocation.Clear();
            foreach (KeyValuePair<Tuple<string,string>,int> keyValuePair in MultiDict)
            {
                var tuple = keyValuePair.Key;
                if(!LockerLocation.Contains(tuple.Item1))
                    LockerLocation.Add(tuple.Item1);
            }
        }

        public void LoadLockerbankData()
        {
            LockerBank.Clear();
            foreach (KeyValuePair<Tuple<string, string>, int> keyValuePair in MultiDict)
            {
                var tuple = keyValuePair.Key;
                if (!LockerBank.Contains(tuple.Item2))
                    LockerBank.Add(tuple.Item2);
            }
        }

        public List<string> GetLockerLocationData()
        {
            return LockerLocation;
        }

        public List<string> GetLockerBankList()
        {
            return LockerBank;
        }

        public int GetlockersCountinLocation(string primaryKey, string subKey)
        {
            MultiDict.TryGetValue(primaryKey, subKey, out var count);
            return count;
        }

        public bool CheckKeyExists(string primaryKey, string subKey)
        {
            MultiDict.TryGetValue(primaryKey, subKey, out var count);
            if(count == 0)
                return false;

            return true;
        }

        public void ClearData()
        {
            MultiDict.Clear();
            LockerBank.Clear();
            LockerLocation.Clear();
        }

        public void AddLocationInfo(string primaryKey, string subKey, int value)
        {
            if (MultiDict.TryGetValue(primaryKey, subKey, out var count))
                return;

            MultiDict.Add(primaryKey, subKey, value);

            LoadLockerLocationData();
            LoadLockerbankData();

            //MultiDict.Add("Syd", "LB1", 10);
            //MultiDict.Add("Syd", "LB2", 20);
            //MultiDict.Add("Syd", "LB3", 30);
            //MultiDict.Add("Syd", "LB4", 40);

            //MultiDict.Add("Mel", "LB1", 11);
            //MultiDict.Add("Mel", "LB2", 21);
            //MultiDict.Add("Mel", "LB3", 31);
            //MultiDict.Add("Mel", "LB4", 41);
        }

        public void LoadDefaultData()
        {
            MultiDict.Add("Syd", "LB1", 10);
            MultiDict.Add("Syd", "LB2", 20);
            MultiDict.Add("Syd", "LB3", 30);
            MultiDict.Add("Syd", "LB4", 40);
            MultiDict.Add("Syd", "LB5", 50);

            MultiDict.Add("Mel", "LB1", 11);
            MultiDict.Add("Mel", "LB2", 21);
            MultiDict.Add("Mel", "LB3", 31);
            MultiDict.Add("Mel", "LB4", 41);
            MultiDict.Add("Mel", "LB5", 51);

            MultiDict.Add("Per", "LB1", 12);
            MultiDict.Add("Per", "LB2", 22);
            MultiDict.Add("Per", "LB3", 32);
            MultiDict.Add("Per", "LB4", 42);
            MultiDict.Add("Per", "LB5", 52);

            MultiDict.Add("Act", "LB1", 13);
            MultiDict.Add("Act", "LB2", 23);
            MultiDict.Add("Act", "LB3", 33);
            MultiDict.Add("Act", "LB4", 43);
            MultiDict.Add("Act", "LB5", 53);

            MultiDict.Add("Bsb", "LB1", 14);
            MultiDict.Add("Bsb", "LB2", 24);
            MultiDict.Add("Bsb", "LB3", 34);
            MultiDict.Add("Bsb", "LB4", 44);
            MultiDict.Add("Bsb", "LB5", 54);

            LoadLockerLocationData();
            LoadLockerbankData();
        }
    }
}
