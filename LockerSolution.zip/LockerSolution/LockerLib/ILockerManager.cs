﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LockerBank
{
    interface ILockerManager
    {
        void LoadLockerLocationData();

        void LoadLockerbankData();

        List<string> GetLockerLocationData();
    }
}
