﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LockerBank;

namespace LockerGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly LockerData _lockerData = null;

        public string Strlocation { get; set; }

        public string StrLockerBank { get; set; }

        DataTable dt;

        DataRow dataRow;

        public MainWindow()
        {
            InitializeComponent();
            _lockerData = new LockerData();
            LoadGridDefaultData();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var locationList = _lockerData.LockerLocation;
            this.LocationCmbBox.ItemsSource = locationList;
            this.LockerBankCmbBox.ItemsSource = _lockerData.LockerBank;
        }

        private void LocationCmbBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Strlocation = LocationCmbBox.SelectedItem.ToString();
            RefreshLockerCountData();
        }

        private void LockerBankCmbBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StrLockerBank = LockerBankCmbBox.SelectedItem.ToString();
            RefreshLockerCountData();
        }

        private void RefreshLockerCountData()
        {
            if (string.IsNullOrEmpty(Strlocation) || string.IsNullOrEmpty(StrLockerBank))
                this.lblLockersCnt.Content = 0;
            else
                this.lblLockersCnt.Content = _lockerData.GetlockersCountinLocation(Strlocation, StrLockerBank);
        }

        void LoadGridDefaultData()
        {
            dt = new DataTable("Locker Info");
            DataColumn dc1 = new DataColumn("Location", typeof(string));
            DataColumn dc2 = new DataColumn("Locker bank", typeof(string));
            DataColumn dc3 = new DataColumn("Count", typeof(string));
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            DataGridLocationLockerInfo.ItemsSource = dt.DefaultView;
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            string _location = this.TxtLocation.Text;
            string _lockerBank = this.TxtLockerBank.Text;
            string _lockerCount = this.TxtLockerCount.Text;

            if (Convert.ToInt32(_lockerCount) > 0)
            {
                if (!_lockerData.CheckKeyExists(_location, _lockerBank))
                {
                    _lockerData.AddLocationInfo(_location, _lockerBank, Convert.ToInt32(_lockerCount));
                    FillDataGrid();
                }
                else
                {
                    MessageBox.Show("Key exists, Try with different name");
                }
            }
            else
            {
                MessageBox.Show("Locker count couldn't be 0.");
            }

        }

        private void FillDataGrid()
        {
            dataRow = dt.NewRow();
            dataRow[0] = this.TxtLocation.Text;
            dataRow[1] = this.TxtLockerBank.Text;
            dataRow[2] = int.Parse(this.TxtLockerCount.Text);
            dt.Rows.Add(dataRow);
            DataGridLocationLockerInfo.ItemsSource = dt.DefaultView;
            this.TxtLocation.Focus();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _lockerData.LoadDefaultData();
            foreach ( KeyValuePair< Tuple<string, string>,int> keyValuePair in _lockerData.MultiDict)
            {
                var tuple = keyValuePair.Key;
                dataRow = dt.NewRow();
                dataRow[0] = tuple.Item1;
                dataRow[1] = tuple.Item2;
                dataRow[2] = keyValuePair.Value;
                dt.Rows.Add(dataRow);
            }
            DataGridLocationLockerInfo.ItemsSource = dt.DefaultView;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            _lockerData.ClearData();
            dt.Clear();
            DataGridLocationLockerInfo.ItemsSource = null;
        }
    }
}
